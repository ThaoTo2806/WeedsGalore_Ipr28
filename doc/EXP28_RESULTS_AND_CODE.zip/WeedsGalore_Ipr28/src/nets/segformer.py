import torch
from torch import nn
from torch.nn import functional as F

# Official MiT checkpoints (hidden sizes b0: 32/64/160/256, b1 and b2: 64/128/320/512)
BACKBONES = {'b0': 'nvidia/mit-b0', 'b1': 'nvidia/mit-b1', 'b2': 'nvidia/mit-b2'}


class OverlapPatchEmbed(nn.Module):
  def __init__(self, in_channels, embed_dim, kernel_size=3, stride=2):
    super(OverlapPatchEmbed, self).__init__()
    self.proj = nn.Conv2d(in_channels, embed_dim, kernel_size, stride,
                          padding=kernel_size // 2, bias=False)
    self.norm = nn.BatchNorm2d(embed_dim)

  def forward(self, x):
    return F.gelu(self.norm(self.proj(x)))


class EfficientSelfAttention(nn.Module):
  def __init__(self, dim, num_heads, sr_ratio):
    super(EfficientSelfAttention, self).__init__()
    if dim % num_heads != 0:
      raise ValueError('dim must be divisible by num_heads')
    self.num_heads = num_heads
    self.head_dim = dim // num_heads
    self.scale = self.head_dim ** -0.5
    self.q = nn.Conv2d(dim, dim, 1, bias=False)
    self.kv = nn.Conv2d(dim, dim * 2, 1, bias=False)
    self.sr_ratio = sr_ratio
    if sr_ratio > 1:
      self.sr = nn.Conv2d(dim, dim, sr_ratio, sr_ratio, bias=False)
      self.sr_norm = nn.BatchNorm2d(dim)
    self.proj = nn.Conv2d(dim, dim, 1, bias=False)

  def forward(self, x):
    batch_size, channels, height, width = x.shape
    query = self.q(x).flatten(2).transpose(1, 2)
    if self.sr_ratio > 1:
      reduced = F.gelu(self.sr_norm(self.sr(x)))
    else:
      reduced = x
    key_value = self.kv(reduced).flatten(2).transpose(1, 2)
    key, value = key_value.chunk(2, dim=-1)

    query = query.reshape(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
    key = key.reshape(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
    value = value.reshape(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
    attention = torch.matmul(query, key.transpose(-2, -1)) * self.scale
    attention = attention.softmax(dim=-1)
    output = torch.matmul(attention, value).transpose(1, 2).reshape(batch_size, -1, channels)
    output = output.transpose(1, 2).reshape(batch_size, channels, height, width)
    return self.proj(output)


class MixFFN(nn.Module):
  def __init__(self, dim, expansion=4):
    super(MixFFN, self).__init__()
    hidden_dim = dim * expansion
    self.fc1 = nn.Conv2d(dim, hidden_dim, 1, bias=False)
    self.dwconv = nn.Conv2d(hidden_dim, hidden_dim, 3, padding=1,
                             groups=hidden_dim, bias=False)
    self.fc2 = nn.Conv2d(hidden_dim, dim, 1, bias=False)
    self.norm = nn.BatchNorm2d(hidden_dim)

  def forward(self, x):
    x = F.gelu(self.norm(self.dwconv(self.fc1(x))))
    return self.fc2(x)


class TransformerBlock(nn.Module):
  def __init__(self, dim, num_heads, sr_ratio):
    super(TransformerBlock, self).__init__()
    self.norm1 = nn.BatchNorm2d(dim)
    self.attention = EfficientSelfAttention(dim, num_heads, sr_ratio)
    self.norm2 = nn.BatchNorm2d(dim)
    self.ffn = MixFFN(dim)

  def forward(self, x):
    x = x + self.attention(self.norm1(x))
    return x + self.ffn(self.norm2(x))


class MiTEncoder(nn.Module):
  def __init__(self, in_channels=5):
    super(MiTEncoder, self).__init__()
    self.dims = (32, 64, 160, 256)
    self.stem = OverlapPatchEmbed(in_channels, 32, kernel_size=7, stride=2)
    self.embed1 = OverlapPatchEmbed(32, 32, stride=2)
    self.embed2 = OverlapPatchEmbed(32, 64, stride=2)
    self.embed3 = OverlapPatchEmbed(64, 160, stride=2)
    self.embed4 = OverlapPatchEmbed(160, 256, stride=2)
    self.stage1 = nn.Sequential(TransformerBlock(32, 1, 8))
    self.stage2 = nn.Sequential(*[TransformerBlock(64, 2, 4) for _ in range(2)])
    self.stage3 = nn.Sequential(*[TransformerBlock(160, 5, 2) for _ in range(2)])
    self.stage4 = nn.Sequential(*[TransformerBlock(256, 8, 1) for _ in range(2)])

  def forward(self, x):
    x = self.stem(x)
    feature1 = self.stage1(self.embed1(x))
    feature2 = self.stage2(self.embed2(feature1))
    feature3 = self.stage3(self.embed3(feature2))
    feature4 = self.stage4(self.embed4(feature3))
    return feature1, feature2, feature3, feature4


class PretrainedMiTEncoder(nn.Module):
  """Official SegFormer MiT-B0 encoder adapted from 3 to 5 input bands.

  The first patch projection keeps the pretrained RGB filters. NIR and RE are
  initialized with the mean RGB filter, then all weights can be fine-tuned.
  """

  def __init__(self, model_name='nvidia/mit-b0', in_channels=5):
    super(PretrainedMiTEncoder, self).__init__()
    try:
      from transformers import SegformerModel
    except ImportError as error:
      raise ImportError(
          'Pretrained SegFormer requires transformers. Install it with '
          '`pip install transformers==4.45.2`.') from error

    pretrained = SegformerModel.from_pretrained(model_name)
    patch_projection = pretrained.encoder.patch_embeddings[0].proj
    if in_channels != 3:
      adapted_projection = nn.Conv2d(
          in_channels, patch_projection.out_channels, patch_projection.kernel_size,
          patch_projection.stride, patch_projection.padding, bias=False)
      with torch.no_grad():
        adapted_projection.weight[:, :3].copy_(patch_projection.weight)
        rgb_mean = patch_projection.weight.mean(dim=1, keepdim=True)
        extra_channels = in_channels - 3
        adapted_projection.weight[:, 3:].copy_(
            rgb_mean.repeat(1, extra_channels, 1, 1))
      pretrained.encoder.patch_embeddings[0].proj = adapted_projection
    self.encoder = pretrained.encoder
    self.config = pretrained.config
    self.dims = tuple(self.config.hidden_sizes)  # stage widths, used by the decoder

  def forward(self, x):
    outputs = self.encoder(x, output_hidden_states=True, return_dict=True)
    hidden_states = outputs.hidden_states
    expected_dims = tuple(self.config.hidden_sizes)
    stage_states = {}
    for hidden_state in hidden_states:
      if hidden_state.dim() == 4:
        channels = hidden_state.shape[1]
      else:
        channels = hidden_state.shape[-1]
      if channels in expected_dims:
        stage_states[channels] = hidden_state

    features = []
    missing = [channels for channels in expected_dims if channels not in stage_states]
    if missing:
      raise RuntimeError(
          f'MiT hidden states do not match expected stage widths. '
          f'Expected {expected_dims}, missing {missing}.')
    for channels in expected_dims:
      hidden_state = stage_states[channels]
      if hidden_state.dim() == 4:
        feature = hidden_state
      else:
        tokens = hidden_state.shape[1]
        height = int(tokens ** 0.5)
        if height * height != tokens:
          raise RuntimeError(f'Cannot reshape MiT hidden state with {tokens} tokens')
        feature = hidden_state.transpose(1, 2).reshape(
            x.shape[0], channels, height, height)
      features.append(feature)
    return tuple(features)


class LowLevelRefine(nn.Module):
  """Shallow conv branch applied directly to the raw 5-band input, kept at half
  resolution (stride-2 conv, no further downsampling). Purpose: the MiT encoder's
  shallowest feature (feature1) is already at 1/4 resolution, and the original decoder
  upsamples straight from there to full resolution in one 4x bilinear step -- with no
  conv in between to reconstruct edges. Thin/small objects (e.g. weed) lose their
  boundary in that single big upsample. This branch gives the decoder a second,
  higher-resolution (1/2) signal carrying raw edge/texture information (including
  NIR/RE contrast) to fuse back in before the final 2x upsample, similar in spirit to
  the low-level-feature fusion in DeepLabV3+'s decoder."""
  def __init__(self, in_channels=5, out_channels=48):
    super(LowLevelRefine, self).__init__()
    self.proj = nn.Sequential(
        nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=2, padding=1, bias=False),
        nn.BatchNorm2d(out_channels),
        nn.ReLU(inplace=True),
    )

  def forward(self, x):
    return self.proj(x)  # (N, out_channels, H/2, W/2)


class SegFormer5Band(nn.Module):
  def __init__(self, num_classes=3, decoder_dim=128, pretrained_backbone=False,
               low_level_channels=48, in_channels=5, use_low_level_refine=True,
               use_multiscale_fusion=True, encoder=None, llr_source='raw', backbone='b0'):
    super(SegFormer5Band, self).__init__()
    if backbone not in BACKBONES:
      raise ValueError(f'backbone must be one of {sorted(BACKBONES)}')
    self.backbone_name = backbone
    if encoder is not None:
      self.encoder = encoder
    elif pretrained_backbone:
      self.encoder = PretrainedMiTEncoder(model_name=BACKBONES[backbone], in_channels=in_channels)
    else:
      if backbone != 'b0':
        raise ValueError('the from-scratch MiTEncoder only implements b0')
      self.encoder = MiTEncoder(in_channels=in_channels)
    # stage widths of the encoder (default b0 keeps checkpoints and fake test encoders compatible)
    dims = tuple(getattr(self.encoder, 'dims', (32, 64, 160, 256)))
    self.encoder_dims = dims
    self.linear1 = nn.Conv2d(dims[0], decoder_dim, 1, bias=False)
    self.use_multiscale_fusion = use_multiscale_fusion
    if use_multiscale_fusion:
      self.linear2 = nn.Conv2d(dims[1], decoder_dim, 1, bias=False)
      self.linear3 = nn.Conv2d(dims[2], decoder_dim, 1, bias=False)
      self.linear4 = nn.Conv2d(dims[3], decoder_dim, 1, bias=False)
      self.fuse = nn.Sequential(
        nn.Conv2d(decoder_dim * 4, decoder_dim, 1, bias=False),
        nn.BatchNorm2d(decoder_dim),
        nn.ReLU(inplace=True),
        nn.Conv2d(decoder_dim, decoder_dim, 3, padding=1, groups=decoder_dim, bias=False),
        nn.BatchNorm2d(decoder_dim),
        nn.ReLU(inplace=True),
      )
    self.use_low_level_refine = use_low_level_refine
    # llr_source (controls requested in the review): 'raw' = LiteSent (raw 5-band branch);
    # 'none' = same 1/2-resolution refine decoder WITHOUT any low-level input;
    # 'f1' = low-level input is the MiT stage-1 feature F1 (upsampled x2) instead of raw bands.
    if llr_source not in ('raw', 'none', 'f1'):
      raise ValueError('llr_source must be raw, none or f1')
    self.llr_source = llr_source
    if use_low_level_refine:
      refine_in = decoder_dim + (0 if llr_source == 'none' else low_level_channels)
      if llr_source == 'raw':
        self.low_level = LowLevelRefine(in_channels=in_channels, out_channels=low_level_channels)
      elif llr_source == 'f1':
        self.low_level = nn.Sequential(
          nn.Conv2d(dims[0], low_level_channels, kernel_size=1, bias=False),
          nn.BatchNorm2d(low_level_channels),
          nn.ReLU(inplace=True),
        )
      self.refine = nn.Sequential(
        nn.Conv2d(refine_in, decoder_dim, kernel_size=3, padding=1, bias=False),
        nn.BatchNorm2d(decoder_dim),
        nn.ReLU(inplace=True),
        nn.Conv2d(decoder_dim, decoder_dim, kernel_size=3, padding=1, groups=decoder_dim, bias=False),
        nn.BatchNorm2d(decoder_dim),
        nn.ReLU(inplace=True),
      )
    self.classifier = nn.Conv2d(decoder_dim, num_classes, 1)

  def forward(self, x):
    return self.decode(x, self.encoder(x))

  def decode(self, x, encoder_features):
    output = self.classifier(self.decode_features(x, encoder_features))
    return F.interpolate(output, size=x.shape[-2:], mode='bilinear', align_corners=False)

  def decode_features(self, x, encoder_features):
    """Decoder feature map before the classifier (1/4 res, or 1/2 res with the refine branch)."""
    input_size = x.shape[-2:]
    feature1, feature2, feature3, feature4 = encoder_features
    target_size = feature1.shape[-2:]  # 1/4 resolution
    if self.use_multiscale_fusion:
      features = [self.linear1(feature1), self.linear2(feature2),
                  self.linear3(feature3), self.linear4(feature4)]
      features = [F.interpolate(feature, size=target_size, mode='bilinear', align_corners=False)
                  for feature in features]
      coarse = self.fuse(torch.cat(features, dim=1))
    else:
      coarse = self.linear1(feature1)

    if self.use_low_level_refine:
      half_size = ((input_size[0] + 1) // 2, (input_size[1] + 1) // 2)  # = stride-2 conv output
      coarse_up = F.interpolate(coarse, size=half_size, mode='bilinear', align_corners=False)
      if self.llr_source == 'raw':
        parts = [coarse_up, self.low_level(x)]
      elif self.llr_source == 'f1':
        f1_up = F.interpolate(feature1, size=half_size, mode='bilinear', align_corners=False)
        parts = [coarse_up, self.low_level(f1_up)]
      else:
        parts = [coarse_up]
      coarse = self.refine(torch.cat(parts, dim=1))

    return coarse